ALTER TABLE quest_objectifs RENAME quest_step;
ALTER TABLE quest_etapes RENAME quest_objective;
ALTER TABLE quest_objectives RENAME COLUMN objectif TO quest_step;
ALTER TABLE quest_data RENAME COLUMN etapes TO steps;
ALTER TABLE quest_data RENAME COLUMN objectif TO objectives;
ALTER TABLE quest_data RENAME quest;

ALTER TABLE quest RENAME COLUMN steps TO objectivess;
ALTER TABLE quest RENAME COLUMN objectives TO steps;
ALTER TABLE quest RENAME COLUMN objectivess TO objectives;