ALTER TABLE quest_objectifs RENAME quest_steps;
ALTER TABLE quest_etapes RENAME quest_objectives;
ALTER TABLE quest_objectives RENAME COLUMN objectif TO quest_step;
ALTER TABLE quest_data RENAME COLUMN etapes TO steps;
ALTER TABLE quest_data RENAME COLUMN objectif TO objectives;
ALTER TABLE quest_data RENAME quest;